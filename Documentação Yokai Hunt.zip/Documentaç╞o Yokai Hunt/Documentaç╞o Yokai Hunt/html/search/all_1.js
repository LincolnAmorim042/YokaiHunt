var searchData=
[
  ['battle_0',['Battle',['../class_battle.html',1,'Battle'],['../class_battle.html#a0385d3ea994ae1cfd576f1297b609668',1,'Battle::Battle(std::string nomem, int atky1, int atky2, const std::string &amp;sprite, const std::string &amp;sprite2, const std::string &amp;portrait, float, float)']]],
  ['battle_1',['battle',['../class_battle.html#a924ef16c9e4a8a4406c0656b66fa7fbe',1,'Battle']]],
  ['battle_2ecpp_2',['Battle.cpp',['../_battle_8cpp.html',1,'']]],
  ['battle_2eh_3',['Battle.h',['../_battle_8h.html',1,'']]]
];
