var indexSectionsWithContent =
{
  0: "abcdfghimps",
  1: "b",
  2: "bcm",
  3: "bcfgm",
  4: "i",
  5: "acdhps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis",
  5: "Definições e Macros"
};

