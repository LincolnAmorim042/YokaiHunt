var searchData=
[
  ['finalbattle_0',['finalbattle',['../_battle_8cpp.html#a3a14c67a2a58547c76389463a89a41eb',1,'finalbattle(RenderWindow &amp;window):&#160;Battle.cpp'],['../_battle_8h.html#ad09f07c9a50726d1ff70c0af7dc608b6',1,'finalbattle(RenderWindow &amp;):&#160;Battle.cpp']]]
];
