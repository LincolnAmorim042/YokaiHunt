var searchData=
[
  ['battle_0',['Battle',['../class_battle.html#a0385d3ea994ae1cfd576f1297b609668',1,'Battle']]],
  ['battle_1',['battle',['../class_battle.html#a924ef16c9e4a8a4406c0656b66fa7fbe',1,'Battle']]]
];
